using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Web;
using Blazor_Nextjs_Level_2.Services;
using Blazor_Nextjs_Level_2.Dev;
using Yarp.ReverseProxy;
using Yarp.ReverseProxy.Configuration;
using Yarp.ReverseProxy.Forwarder;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddRazorPages();
builder.Services.AddServerSideBlazor();
builder.Services.AddSingleton<ITimeService, SystemTimeService>();
builder.Services.AddSingleton<Blazor_Nextjs_Level_2.Data.WeatherForecastService>();

builder.Services.AddHostedService<NextDevHostedService>();
builder.Services.AddHttpClient();

var nextUrl = builder.Configuration["NEXT_URL"] ?? "http://localhost:3000";

builder.Services.AddReverseProxy().LoadFromMemory(
    routes: new[]
    {
        new RouteConfig { RouteId = "next", ClusterId = "next",
            Match = new RouteMatch { Path = "/next/{**catchall}" } }
    },
    clusters: new[]
    {
        new ClusterConfig
        {
            ClusterId = "next",
            Destinations = new Dictionary<string, DestinationConfig>
            {
                ["d1"] = new DestinationConfig { Address = nextUrl }
            },
            HttpRequest = new ForwarderRequestConfig
            {
                ActivityTimeout = TimeSpan.FromMinutes(2)
            }
        }
    });

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseWebSockets();

app.MapGet("/healthz", async (IHttpClientFactory http) =>
{
    try
    {
        var res = await http.CreateClient().GetAsync($"{nextUrl}/next/api/ping");
        return res.IsSuccessStatusCode ? Results.Ok(new { ok = true }) : Results.StatusCode(503);
    }
    catch { return Results.StatusCode(503); }
});

app.MapBlazorHub();
app.MapFallbackToPage("/_Host");
app.MapReverseProxy();

app.Run();
