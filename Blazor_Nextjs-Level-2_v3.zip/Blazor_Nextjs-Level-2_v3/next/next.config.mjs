/** @type {import('next').NextConfig} */
const nextConfig={ basePath:'/next'};
export default nextConfig;
