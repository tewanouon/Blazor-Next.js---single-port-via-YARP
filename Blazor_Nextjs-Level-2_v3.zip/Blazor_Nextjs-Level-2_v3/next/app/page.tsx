'use client';
import { useEffect, useState } from 'react';
function sid(): string { const k='sid'; let v=sessionStorage.getItem(k); if(!v){ v=crypto.randomUUID(); sessionStorage.setItem(k,v);} return v; }
export default function Page(){
  const [count,setCount]=useState<number|null>(null); const [loading,setLoading]=useState(true);
  const headers=()=>({'x-session-id':sid()});
  async function refresh(){ setLoading(true); const r=await fetch('/next/api/session',{headers:headers(),cache:'no-store'}); const d=await r.json(); setCount(d.count??0); setLoading(false); }
  async function inc(){ const r=await fetch('/next/api/session',{method:'POST',headers:{...headers(),'content-type':'application/json'},body:JSON.stringify({op:'inc'})}); setCount((await r.json()).count); }
  async function reset(){ const r=await fetch('/next/api/session',{method:'POST',headers:{...headers(),'content-type':'application/json'},body:JSON.stringify({op:'reset'})}); setCount((await r.json()).count); }
  useEffect(()=>{ refresh(); },[]);
  return(<div><h3>Memory Session Counter (no cookies)</h3>{loading?<p>Loading...</p>:<div style={{display:'flex',gap:8,alignItems:'center'}}><strong>Count: {count}</strong><button onClick={inc}>+1</button><button onClick={reset}>Reset</button></div>}<p style={{marginTop:8,color:'#64748b'}}>Session id in <code>sessionStorage</code>, sent via <code>X-Session-Id</code>.</p></div>);
}
