import { NextRequest, NextResponse } from 'next/server'; export const runtime='nodejs';
type Todo={id:string; title:string; done:boolean}; const g=global as any; g.__todoStore??=new Map<string,Todo[]>(); const store:Map<string,Todo[]>=g.__todoStore;
const sid=(req:NextRequest)=>req.headers.get('x-session-id')??'anon';
export async function GET(req:NextRequest){ const key=sid(req); return NextResponse.json(store.get(key)??[]); }
export async function POST(req:NextRequest){ const key=sid(req); const body=await req.json().catch(()=>({})); const title=(body?.title??'').toString().trim(); if(!title) return NextResponse.json({error:'title required'},{status:400}); const list=store.get(key)??[]; const t:Todo={id:crypto.randomUUID(),title,done:false}; store.set(key,[t,...list]); return NextResponse.json(t,{status:201}); }
export async function DELETE(req:NextRequest){ const key=sid(req); const id=new URL(req.url).searchParams.get('id'); if(!id) return NextResponse.json({error:'id required'},{status:400}); const list=(store.get(key)??[]).filter(x=>x.id!==id); store.set(key,list); return NextResponse.json({ok:true}); }
