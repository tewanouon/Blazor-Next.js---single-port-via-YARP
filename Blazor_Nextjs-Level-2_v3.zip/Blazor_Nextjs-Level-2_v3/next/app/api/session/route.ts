import { NextRequest, NextResponse } from 'next/server'; export const runtime='nodejs';
type Session={count:number}; const g=global as any; g.__memSessions??=new Map<string,Session>(); const sessions:Map<string,Session>=g.__memSessions;
const sid=(req:NextRequest)=>req.headers.get('x-session-id');
export async function GET(req:NextRequest){const id=sid(req)??'anon';const s=sessions.get(id)??{count:0};sessions.set(id,s);return NextResponse.json(s);}
export async function POST(req:NextRequest){const id=sid(req); if(!id) return NextResponse.json({error:'Missing x-session-id'},{status:400});
const body=await req.json().catch(()=>({}));const s=sessions.get(id)??{count:0}; if(body.op==='inc') s.count+=1; else if(body.op==='reset') s.count=0; sessions.set(id,s); return NextResponse.json(s);}