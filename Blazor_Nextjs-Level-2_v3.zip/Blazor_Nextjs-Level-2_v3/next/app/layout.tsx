export const metadata = { title: 'Next Level-2' };
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body style={{fontFamily:'system-ui, Segoe UI, Roboto, Arial, sans-serif', padding: 16}}>
        <h2>Next.js (Level-2)</h2>
        <p>Served under <code>/next</code>. Proxied by YARP (single port). In-memory session.</p>
        <hr/>{children}
      </body>
    </html>
  );
}
