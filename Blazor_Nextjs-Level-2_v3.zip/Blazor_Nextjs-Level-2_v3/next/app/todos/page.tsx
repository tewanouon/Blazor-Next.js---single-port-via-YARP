'use client';
import { useEffect, useState } from 'react';
type Todo={id:string; title:string; done:boolean};
function sid():string{ const k='sid'; let v=sessionStorage.getItem(k); if(!v){ v=crypto.randomUUID(); sessionStorage.setItem(k,v);} return v; }
export default function TodosPage(){
  const [items,setItems]=useState<Todo[]>([]); const [title,setTitle]=useState('');
  const headers={'x-session-id':sid(),'content-type':'application/json'};
  async function load(){ const r=await fetch('/next/api/todos',{headers,cache:'no-store'}); setItems(await r.json()); }
  async function add(){ if(!title.trim()) return; const r=await fetch('/next/api/todos',{method:'POST',headers,body:JSON.stringify({title})}); const t:Todo=await r.json(); setItems([t,...items]); setTitle(''); }
  async function remove(id:string){ await fetch(`/next/api/todos?id=${id}`,{method:'DELETE',headers:{'x-session-id':sid()}}); setItems(items.filter(x=>x.id!==id)); }
  useEffect(()=>{ load(); },[]);
  return(<div><h3>Todos (memory, no cookies)</h3>
    <div style={{display:'flex',gap:8,margin:'8px 0'}}><input value={title} onChange={e=>setTitle(e.target.value)} placeholder="What to do?"/><button onClick={add}>Add</button></div>
    {items.length===0?<p>No items.</p>:<ul>{items.map(t=>(<li key={t.id} style={{display:'flex',gap:8,alignItems:'center'}}><span>{t.title}</span><button onClick={()=>remove(t.id)}>x</button></li>))}</ul>}
  </div>);
}
