namespace Blazor_Nextjs_Level_2.Data;
public class WeatherForecastService{
  static readonly string[] Summaries={"Freezing","Bracing","Chilly","Cool","Mild","Warm","Balmy","Hot","Sweltering","Scorching"};
  public Task<WeatherForecast[]> GetForecastAsync(DateOnly startDate)=>Task.FromResult(
    Enumerable.Range(1,5).Select(i=>new WeatherForecast{Date=startDate.AddDays(i),TemperatureC=Random.Shared.Next(-20,55),Summary=Summaries[Random.Shared.Next(Summaries.Length)]}).ToArray());
}