using System.Diagnostics;

namespace Blazor_Nextjs_Level_2.Dev;

public class NextDevHostedService : BackgroundService
{
    private readonly IWebHostEnvironment _env;
    private Process? _proc;

    public NextDevHostedService(IWebHostEnvironment env) => _env = env;

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        if (!_env.IsDevelopment()) return;
        var nextDir = Path.Combine(_env.ContentRootPath, "next");
        if (!Directory.Exists(nextDir)) return;
        try
        {
            var lockFile = Path.Combine(nextDir, "package-lock.json");
            var installCmd = File.Exists(lockFile) ? "npm ci" : "npm install";
            await RunOnce(ShellWrap(installCmd), nextDir, stoppingToken);
            _proc = StartDetached(ShellWrap("npm run dev"), nextDir);
        }
        catch { }
        while (!stoppingToken.IsCancellationRequested)
            await Task.Delay(1000, stoppingToken);
    }

    private static (string file, string args) ShellWrap(string raw)
        => OperatingSystem.IsWindows()
            ? ("cmd.exe", "/c " + raw)
            : ("/bin/bash", "-lc \"" + raw.Replace("\"", "\\\"") + "\"");

    private static async Task RunOnce((string file,string args) cmd, string dir, CancellationToken ct)
    {
        try
        {
            var p = new Process
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName = cmd.file,
                    Arguments = cmd.args,
                    WorkingDirectory = dir,
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    CreateNoWindow = true
                }
            };
            p.Start();
            await p.WaitForExitAsync(ct);
        }
        catch { }
    }

    private static Process StartDetached((string file,string args) cmd, string dir)
    {
        var p = new Process
        {
            StartInfo = new ProcessStartInfo
            {
                FileName = cmd.file,
                Arguments = cmd.args,
                WorkingDirectory = dir,
                UseShellExecute = true,
                CreateNoWindow = false
            }
        };
        p.Start();
        return p;
    }

    public override Task StopAsync(CancellationToken cancellationToken)
    {
        try { _proc?.Kill(true); } catch { }
        return base.StopAsync(cancellationToken);
    }
}
