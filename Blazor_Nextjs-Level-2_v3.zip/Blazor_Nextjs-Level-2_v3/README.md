# Blazor_Nextjs-Level-2 v3
YARP without transforms, health at /healthz, Next under /next.
